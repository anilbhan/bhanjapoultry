(function () {
  const STORAGE_KEY = "bbhanja.poultry.content.v1";

  const defaultContent = {
    business: {
      name: "B Bhanja Poultry Supply",
      tagline: "Reliable poultry supply in Pokhara",
      location: "Amarsingh, Pokhara, Nepal",
      hours: "6:00 AM - 7:00 PM"
    },
    hero: {
      kicker: "Amarsingh, Pokhara Nepal",
      title: "B Bhanja Poultry Supply",
      subtitle: "Fresh poultry products, healthy birds, quality feed, and regular supply support for farms, shops, homes, and butchers."
    },
    productsIntro: "We supply daily poultry needs with reliable local coordination, practical quantities, and fresh stock.",
    whyCopy: "We focus on clean sourcing, dependable quantities, practical feed guidance, and quick local coordination for regular buyers.",
    products: [
      { title: "Broiler Chickens", icon: "bi-egg-fried", description: "Healthy broiler birds for meat production and regular market demand.", badge: "Meat Birds" },
      { title: "Layer Birds", icon: "bi-box2-heart", description: "Layer supply for egg-focused farms and growing poultry operations.", badge: "Egg Production" },
      { title: "Day-Old Chicks", icon: "bi-brightness-high", description: "Fresh chicks for farms starting or expanding poultry batches.", badge: "Chicks" },
      { title: "Fresh Eggs", icon: "bi-egg", description: "Clean eggs for homes, shops, hotels, and local retailers.", badge: "Daily Stock" },
      { title: "Poultry Feed", icon: "bi-bag-check", description: "Feed options for broiler, layer, and chick growth stages.", badge: "Feed" },
      { title: "Fresh Chicken for Butchers", icon: "bi-shop", description: "Regular fresh chicken supply arranged for butcher shops and meat sellers.", badge: "Butcher Supply" }
    ],
    features: [
      { title: "Local Availability", icon: "bi-geo-alt", description: "Easy coordination from Amarsingh for buyers around Pokhara." },
      { title: "Fresh and Practical", icon: "bi-check2-circle", description: "Stock is handled for freshness, quality, and daily business needs." },
      { title: "Bulk Friendly", icon: "bi-truck", description: "Support for repeat orders and regular supply for butchers and shops." },
      { title: "Feed Guidance", icon: "bi-chat-square-text", description: "Helpful support for choosing feed by bird type and growth stage." }
    ],
    stats: [
      { value: "6+", label: "Product Categories" },
      { value: "Daily", label: "Fresh Stock" },
      { value: "Local", label: "Pokhara Service" },
      { value: "Bulk", label: "Butcher Orders" }
    ],
    about: {
      title: "Serving poultry needs from Amarsingh",
      copy: "B Bhanja Poultry Supply provides poultry products and farm necessities for customers across Pokhara. Our business supports butchers, farms, shops, and families with practical service, fresh stock, and reliable coordination.",
    },
    highlights: [
      { title: "Butcher Supply", description: "Fresh chicken orders can be coordinated for regular meat sellers." },
      { title: "Farm Essentials", description: "Broilers, layers, chicks, eggs, and feed available from one place." }
    ],
    gallery: [
      { title: "Egg Trays", description: "Fresh eggs for household and retail demand.", icon: "bi-egg" },
      { title: "Feed Sacks", description: "Poultry feed for healthy growth stages.", icon: "bi-bag" },
      { title: "Fresh Chicken", description: "Reliable supply for local butchers.", icon: "bi-shop-window" }
    ],
    contact: {
      phone: "+977 9800000000",
      email: "info@bbhanjapoultry.com",
      address: "Amarsingh, Pokhara, Nepal",
      mapUrl: "https://maps.google.com/?q=Amarsingh%20Pokhara%20Nepal",
      copy: "Contact us for daily rates, available stock, feed orders, or regular supply arrangements for butchers."
    }
  };

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function mergeDefaults(defaults, saved) {
    if (!saved || typeof saved !== "object") return clone(defaults);
    if (Array.isArray(defaults)) return Array.isArray(saved) ? saved : clone(defaults);
    return Object.keys(defaults).reduce((result, key) => {
      const defaultValue = defaults[key];
      const savedValue = saved[key];
      if (defaultValue && typeof defaultValue === "object" && !Array.isArray(defaultValue)) {
        result[key] = mergeDefaults(defaultValue, savedValue);
      } else {
        result[key] = savedValue === undefined ? clone(defaultValue) : savedValue;
      }
      return result;
    }, {});
  }

  async function requestJson(url, options) {
    const response = await fetch(url, options);
    if (!response.ok) throw new Error(`Request failed: ${response.status}`);
    return response.json();
  }

  async function getContent() {
    if (window.location.protocol !== "file:") {
      try {
        const data = await requestJson("/api/content");
        return mergeDefaults(defaultContent, data.content);
      } catch (error) {
        console.warn("Falling back to browser content store.", error);
      }
    }

    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
      return mergeDefaults(defaultContent, saved);
    } catch (error) {
      return clone(defaultContent);
    }
  }

  async function saveContent(content) {
    if (window.location.protocol !== "file:") {
      const data = await requestJson("/api/content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content })
      });
      return mergeDefaults(defaultContent, data.content);
    }

    localStorage.setItem(STORAGE_KEY, JSON.stringify(content, null, 2));
    return content;
  }

  async function resetContent() {
    if (window.location.protocol !== "file:") {
      const data = await requestJson("/api/content/reset", { method: "POST" });
      return mergeDefaults(defaultContent, data.content);
    }

    localStorage.removeItem(STORAGE_KEY);
    return clone(defaultContent);
  }

  window.BBhanjaContent = {
    STORAGE_KEY,
    defaultContent: clone(defaultContent),
    getContent,
    saveContent,
    resetContent,
    clone
  };
})();
