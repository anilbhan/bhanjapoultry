(function () {
  const form = document.querySelector("[data-login-form]");
  const alertBox = document.querySelector("[data-login-alert]");

  function showError(message) {
    alertBox.textContent = message;
    alertBox.classList.remove("d-none");
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    alertBox.classList.add("d-none");
    const formData = new FormData(form);

    try {
      const response = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: formData.get("username"),
          password: formData.get("password")
        })
      });

      if (!response.ok) {
        showError("Invalid username or password.");
        return;
      }

      window.location.href = "/admin";
    } catch (error) {
      showError("Please run the website through server.js before logging in.");
    }
  });
})();
