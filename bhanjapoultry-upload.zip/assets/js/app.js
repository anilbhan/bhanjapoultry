(async function () {
  const content = await window.BBhanjaContent.getContent();

  function escapeHtml(value) {
    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function setText(selector, value) {
    document.querySelectorAll(selector).forEach((node) => {
      node.textContent = value || "";
    });
  }

  function setLink(selector, href) {
    document.querySelectorAll(selector).forEach((node) => {
      node.href = href || "#";
    });
  }

  function iconClass(icon) {
    return icon && icon.startsWith("bi-") ? icon : "bi-check2-circle";
  }

  function renderProducts() {
    const target = document.querySelector("[data-products-list]");
    target.innerHTML = content.products.map((item) => `
      <div class="col-md-6 col-xl-4">
        <article class="product-card h-100">
          <div class="d-flex justify-content-between align-items-start gap-3 mb-3">
            <span class="product-icon"><i class="bi ${iconClass(item.icon)}"></i></span>
            <span class="badge rounded-pill text-bg-success">${escapeHtml(item.badge || "Available")}</span>
          </div>
          <h3>${escapeHtml(item.title)}</h3>
          <p>${escapeHtml(item.description)}</p>
        </article>
      </div>
    `).join("");
  }

  function renderFeatures() {
    const target = document.querySelector("[data-features-list]");
    target.innerHTML = content.features.map((item) => `
      <div class="col-sm-6">
        <article class="feature-tile">
          <span class="feature-icon"><i class="bi ${iconClass(item.icon)}"></i></span>
          <h3>${escapeHtml(item.title)}</h3>
          <p>${escapeHtml(item.description)}</p>
        </article>
      </div>
    `).join("");
  }

  function renderStats() {
    const target = document.querySelector("[data-stats-list]");
    target.innerHTML = content.stats.map((item) => `
      <div class="col-6 col-lg-3">
        <div class="stat-tile">
          <strong>${escapeHtml(item.value)}</strong>
          <span>${escapeHtml(item.label)}</span>
        </div>
      </div>
    `).join("");
  }

  function renderHighlights() {
    const target = document.querySelector("[data-highlights-list]");
    target.innerHTML = content.highlights.map((item) => `
      <div class="col-sm-6">
        <div class="highlight-box">
          <h3>${escapeHtml(item.title)}</h3>
          <p>${escapeHtml(item.description)}</p>
        </div>
      </div>
    `).join("");
  }

  function renderGallery() {
    const target = document.querySelector("[data-gallery-list]");
    target.innerHTML = content.gallery.map((item) => `
      <div class="col-md-4">
        <article class="order-card">
          <i class="bi ${iconClass(item.icon)}"></i>
          <h3>${escapeHtml(item.title)}</h3>
          <p>${escapeHtml(item.description)}</p>
        </article>
      </div>
    `).join("");
  }

  function renderInterestOptions() {
    const target = document.querySelector("[data-interest-select]");
    target.innerHTML = content.products.map((item) => `<option>${escapeHtml(item.title)}</option>`).join("");
  }

  function bindContactForm() {
    const form = document.querySelector("[data-contact-form]");
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const data = new FormData(form);
      const message = [
        `Hello ${content.business.name},`,
        `My name is ${data.get("name")}. I am interested in ${data.get("interest")}.`,
        data.get("message"),
        `Phone: ${data.get("phone")}`
      ].join("%0A");
      window.location.href = `tel:${content.contact.phone.replace(/\s/g, "")}`;
      setTimeout(() => {
        window.location.href = `mailto:${content.contact.email}?subject=Poultry Supply Inquiry&body=${message}`;
      }, 350);
    });
  }

  document.title = `${content.business.name} | ${content.business.location}`;
  setText("[data-business-name]", content.business.name);
  setText("[data-hero-kicker]", content.hero.kicker);
  setText("[data-hero-title]", content.hero.title);
  setText("[data-hero-subtitle]", content.hero.subtitle);
  setText("[data-location]", content.business.location);
  setText("[data-hours]", content.business.hours);
  setText("[data-products-intro]", content.productsIntro);
  setText("[data-why-copy]", content.whyCopy);
  setText("[data-about-title]", content.about.title);
  setText("[data-about-copy]", content.about.copy);
  setText("[data-contact-copy]", content.contact.copy);
  setText("[data-contact-phone]", content.contact.phone);
  setText("[data-contact-email]", content.contact.email);
  setText("[data-contact-address]", content.contact.address);
  setText("[data-phone-text]", content.contact.phone);
  setText("[data-year]", new Date().getFullYear());
  setLink("[data-phone-link]", `tel:${content.contact.phone.replace(/\s/g, "")}`);
  setLink("[data-email-link]", `mailto:${content.contact.email}`);
  setLink("[data-map-link]", content.contact.mapUrl);

  renderStats();
  renderProducts();
  renderFeatures();
  renderHighlights();
  renderGallery();
  renderInterestOptions();
  bindContactForm();
})();
