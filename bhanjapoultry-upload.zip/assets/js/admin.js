(async function () {
  if (window.location.protocol === "file:") {
    document.body.innerHTML = `
      <main class="login-shell">
        <section class="login-card">
          <span class="eyebrow text-danger">Server Required</span>
          <h1>Admin is protected by the server</h1>
          <p class="text-muted">Start the website with <strong>node server.js</strong> and open <strong>http://localhost:3000/admin</strong>.</p>
        </section>
      </main>
    `;
    return;
  }

  const sessionResponse = await fetch("/api/session");
  if (!sessionResponse.ok) {
    window.location.href = "/login";
    return;
  }

  const session = await sessionResponse.json();
  let content = await window.BBhanjaContent.getContent();
  const form = document.querySelector("[data-admin-form]");
  const alertBox = document.querySelector("[data-alert]");

  const listSchemas = {
    products: [
      ["title", "Title"],
      ["badge", "Badge"],
      ["icon", "Bootstrap Icon"],
      ["description", "Description", "textarea"]
    ],
    features: [
      ["title", "Title"],
      ["icon", "Bootstrap Icon"],
      ["description", "Description", "textarea"]
    ],
    stats: [
      ["value", "Value"],
      ["label", "Label"]
    ],
    highlights: [
      ["title", "Title"],
      ["description", "Description", "textarea"]
    ],
    gallery: [
      ["title", "Title"],
      ["icon", "Bootstrap Icon"],
      ["description", "Description", "textarea"]
    ]
  };

  const blankItems = {
    products: { title: "New Product", icon: "bi-check2-circle", description: "Add product details.", badge: "Available" },
    features: { title: "New Feature", icon: "bi-check2-circle", description: "Add feature details." },
    stats: { value: "New", label: "Stat Label" },
    highlights: { title: "New Highlight", description: "Add highlight details." },
    gallery: { title: "New Order", description: "Add popular order details.", icon: "bi-basket" }
  };

  function getPath(path) {
    return path.split(".").reduce((value, key) => value && value[key], content);
  }

  function setPath(path, value) {
    const keys = path.split(".");
    const last = keys.pop();
    const target = keys.reduce((node, key) => node[key], content);
    target[last] = value;
  }

  function showAlert(message, type = "success") {
    alertBox.className = `alert alert-${type}`;
    alertBox.textContent = message;
    setTimeout(() => alertBox.classList.add("d-none"), 3500);
  }

  function escapeHtml(value) {
    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function escapeAttribute(value) {
    return escapeHtml(value).replace(/`/g, "&#096;");
  }

  function fillFields() {
    document.querySelectorAll("[data-field]").forEach((field) => {
      field.value = getPath(field.dataset.field) || "";
    });
  }

  function collectFields() {
    document.querySelectorAll("[data-field]").forEach((field) => {
      setPath(field.dataset.field, field.value.trim());
    });
  }

  function itemField(name, value, index, key, type) {
    const id = `${name}-${index}-${key}`;
    const inputAttrs = `class="form-control" id="${id}" data-item-list="${name}" data-item-index="${index}" data-item-key="${key}"`;
    if (type === "textarea") {
      return `
        <div class="col-12">
          <label class="form-label" for="${id}">${value[1]}</label>
          <textarea ${inputAttrs} rows="2">${escapeHtml(content[name][index][key])}</textarea>
        </div>
      `;
    }
    return `
      <div class="col-md-4">
        <label class="form-label" for="${id}">${value[1]}</label>
        <input ${inputAttrs} type="text" value="${escapeAttribute(content[name][index][key])}">
      </div>
    `;
  }

  function renderList(name) {
    const target = document.querySelector(`[data-list-editor="${name}"]`);
    const schema = listSchemas[name];
    target.innerHTML = content[name].map((item, index) => `
      <div class="editor-item">
        <div class="editor-item-header">
          <strong>${escapeHtml(item.title || item.label || `Item ${index + 1}`)}</strong>
          <button class="btn btn-sm btn-outline-danger" type="button" data-remove="${name}" data-index="${index}"><i class="bi bi-trash"></i></button>
        </div>
        <div class="row g-3">
          ${schema.map(([key, label, type]) => itemField(name, [key, label], index, key, type)).join("")}
        </div>
      </div>
    `).join("");
  }

  function renderLists() {
    Object.keys(listSchemas).forEach(renderList);
  }

  function collectLists() {
    document.querySelectorAll("[data-item-list]").forEach((field) => {
      const list = field.dataset.itemList;
      const index = Number(field.dataset.itemIndex);
      const key = field.dataset.itemKey;
      content[list][index][key] = field.value.trim();
    });
  }

  async function save() {
    collectFields();
    collectLists();
    content = await window.BBhanjaContent.saveContent(content);
    renderLists();
    showAlert("Website content saved to the server database.");
  }

  function downloadJson() {
    collectFields();
    collectLists();
    const blob = new Blob([JSON.stringify(content, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "bbhanja-poultry-content.json";
    link.click();
    URL.revokeObjectURL(url);
  }

  document.querySelector("[data-save]").addEventListener("click", save);
  document.querySelector("[data-export]").addEventListener("click", downloadJson);
  document.querySelector("[data-reset]").addEventListener("click", async () => {
    if (!confirm("Reset all website content to the original version?")) return;
    content = await window.BBhanjaContent.resetContent();
    fillFields();
    renderLists();
    showAlert("Content reset to the default version.");
  });

  document.querySelector("[data-logout]").addEventListener("click", async () => {
    await fetch("/api/logout", { method: "POST" });
    window.location.href = "/login";
  });

  document.querySelector("[data-change-password]").addEventListener("click", async () => {
    const username = document.querySelector("[data-credential='username']").value.trim();
    const password = document.querySelector("[data-credential='password']").value;

    if (!username || password.length < 10) {
      showAlert("Use a username and a password with at least 10 characters.", "danger");
      return;
    }

    const response = await fetch("/api/credentials", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password })
    });

    if (!response.ok) {
      showAlert("Could not update login credentials.", "danger");
      return;
    }

    document.querySelector("[data-credential='password']").value = "";
    showAlert("Admin login credentials updated.");
  });

  document.querySelector("[data-import]").addEventListener("change", (event) => {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        content = JSON.parse(reader.result);
        content = await window.BBhanjaContent.saveContent(content);
        fillFields();
        renderLists();
        showAlert("Imported content successfully.");
      } catch (error) {
        showAlert("That file could not be imported. Please use a valid JSON export.", "danger");
      }
    };
    reader.readAsText(file);
  });

  document.addEventListener("click", (event) => {
    const addButton = event.target.closest("[data-add]");
    if (addButton) {
      collectFields();
      collectLists();
      const name = addButton.dataset.add;
      content[name].push(window.BBhanjaContent.clone(blankItems[name]));
      renderList(name);
    }

    const removeButton = event.target.closest("[data-remove]");
    if (removeButton) {
      collectFields();
      collectLists();
      const name = removeButton.dataset.remove;
      const index = Number(removeButton.dataset.index);
      content[name].splice(index, 1);
      renderList(name);
    }
  });

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    save();
  });

  document.querySelector("[data-credential='username']").value = session.user.username;
  fillFields();
  renderLists();
})();
